import { getMarkerList } from "@/api/marker";


//获取和渲染工厂点位信息
export const getMarker = (AMap,map) => {
    getMarkerList().then((res) => {
      res.data.data.forEach((element) => {
        console.log(element);
        const marker = new AMap.Marker({
          position: new AMap.LngLat(element.longitude, element.latitude), //经纬度对象，也可以是经纬度构成的一维数组[116.39, 39.9]
          title: element.name,
        });
        map.add(marker);
      });
    });
  };