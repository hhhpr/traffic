import {http}from "@/utils/http"

export const getMarkerList=()=>{
    return http.request(
        "get",
        "/MarkerList",
        {}
    )
}