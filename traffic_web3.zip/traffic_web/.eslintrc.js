module.exports = {
    globals: {
      AMap: true,
      AMapUI: true,
    },
  };